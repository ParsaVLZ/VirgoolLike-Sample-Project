export enum Roles {
    Admin="admin",
    User="user"
}