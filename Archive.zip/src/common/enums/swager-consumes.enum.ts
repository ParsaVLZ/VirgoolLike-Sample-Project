export enum SwaggerConsumes {
    UrlEncoded="application/x-www-form-urlencoded",
    Json= "application/json",
    MultipartData= "multipart/form-data"
}  