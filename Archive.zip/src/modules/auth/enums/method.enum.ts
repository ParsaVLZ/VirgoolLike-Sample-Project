export enum AuthMethod {
    Username="username",
    Email="email",
    Phone="phone",
}