export enum AuthType {
    Login="login",
    Register="register"
}