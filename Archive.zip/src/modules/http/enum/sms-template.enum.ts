export enum SmsTemplate {
    Verify="verify"
}