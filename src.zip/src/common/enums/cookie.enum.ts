export enum CookieKeys  {
    OTP="otp",
    EmailOTP="email-otp",
    PhoneOTP="phone-otp",
}