export enum EntityName {
    User= "user",
    Profile= "profile",
    Otp= "otp",
    Category= "category",
    Blog= "blog",
    BlogCategory= "blog_category",
    BlogLikes= "blog_likes",
    BlogComments= "blog_comments",
    BlogBookmark= "blog_bookmarks",
    Image= "image",
    Follow= "follow"
}