export enum BlogStatus {
    Published="published",
    Draft="draft",
    Reject="rejected"
}