export enum Gender {
    Men = "مرد",
    Women = "زن",
    Other = "سایر"
}