export enum UserStatus {
    Block="block",
    Report="report",
}